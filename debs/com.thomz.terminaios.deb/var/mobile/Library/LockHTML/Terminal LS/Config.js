var Clock = true; // 12h Clock
var DarkMode = true; // Dark Mode
var Size = false; // Little Mode
var Phone = "Thomz’s phone"; // Write your phone name or a custom text
