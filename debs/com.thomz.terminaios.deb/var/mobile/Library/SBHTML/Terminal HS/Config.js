var Clock = false; // 12h Clock
var DarkMode = false; // Dark Mode
var Size = false; // Little Mode
var Phone = "iPhone"; // Write your phone name or a custom text