var Clock = false; // 12h Clock
var Text = "Hello back"; // Add your custom text
var Color = "white"; // Change the color of the widget just by tapping : red for red,blue for blue,...                                  (You can also use HTML color codes for more specific colors)
var Image = "profile.jpg"; // Place an image via Filza to /var/mobile/Library/SBHTML/Linedget/img/ and put your image here (You can find your gallery folder at /var/mobile/Media/DCIM/101APPLE) and change the text to your image name (with the extension)
var WeatherIcons = "Default"; // choose between Default (for Apple default icons) or Thomz (for my icons)
var Top = false; // Hide Top component
var Bottom = true; // Hide bottom component
