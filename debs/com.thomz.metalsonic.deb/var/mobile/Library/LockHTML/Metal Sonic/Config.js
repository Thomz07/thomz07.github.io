var WhiteText = true; 
