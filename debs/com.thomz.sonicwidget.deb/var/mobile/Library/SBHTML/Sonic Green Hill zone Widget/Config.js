var Clock = "24h"; // choose between "12h" or "24h"
var Lang = "fr"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
