var Clock = false; // 12h Clock
var Wthr = false; // Show the weather instead of the battery
var Nothing = false; // Don’t show battery or weather
var Text = "Hello there"; // Write your text
