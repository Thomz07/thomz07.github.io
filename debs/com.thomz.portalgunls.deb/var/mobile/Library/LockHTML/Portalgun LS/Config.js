var Clock = false; // 12h Clock
